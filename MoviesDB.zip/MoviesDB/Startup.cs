﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Routing.Constraints;
using Microsoft.AspNetCore.StaticFiles;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System.Diagnostics.CodeAnalysis;
using IHostingEnvironment = Microsoft.AspNetCore.Hosting.IHostingEnvironment;
using Swashbuckle.AspNetCore.Swagger;
using Microsoft.OpenApi.Models;
using System.Web.Http.Cors;
using Movies.Model;

namespace MoviesDB
{
    public class Startup
    {
        public IConfiguration Configuration { get; }

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }
        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        public void ConfigureServices(IServiceCollection services)
        {
            // requires: using Microsoft.AspNetCore.Authorization;
            //           using Microsoft.AspNetCore.Mvc.Authorization;

            // use mvc defsult route handling (rather than endpoint handling?)
            services.AddMvc(option => option.EnableEndpointRouting = false);
            // need this
            services.AddControllers();

            // register the DB Context
            services.AddDbContext<DataContext>(options => options.UseSqlServer(Configuration.GetConnectionString("MoviesDB")));

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "MoviesDB.API", Version = "v1" });  
            });

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        [Obsolete]
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory)
        {
            app.UseDefaultFiles();
            FileExtensionContentTypeProvider provider = new FileExtensionContentTypeProvider();

            provider.Mappings[".ts"] = "application/x-typescript";
            StaticFileOptions staticFileOptions = new StaticFileOptions()
            {
                ContentTypeProvider = provider
            };

            app.UseStaticFiles();
            app.UseRouting();
            // enable cross-origin requests from different domains
            // so an http client (browser) will pick up the results of a WEB API
            // request from a different browser domain  (different can mean the same browser but different port)
            app.UseCors(); 

            // app.UseEndpoints(builder => builder.MapControllers());
            //  app.UseEndpoints(endpoints =>
            //   {
            //       endpoints.MapControllers();
            //       endpoints.MapControllerRoute("default", "{controller=Home}/{action=Index}");
            //  });
            // *** conventional routing (as opposed ot attribute based) ******
            //
            // NOTE:
            // (1) localhost:<N> will always default point to your file Index.html in the root of wwwroot IF IT EXISTS
            // (2) If it doesn't exist then it default points to the Index.cshtml under the 'Pages' folder
            //
            // (3) the below default url is localhost:<N>/api/Home/Index -
            // EVEN IF  the bit action = "Index"  wasn't specified as Index is the default mthod in the controller
            //
            app.UseMvc(routes =>
            {
            routes.MapRoute(
                      name: "api",
                      template: "api/{controller}/{action}/{id?}",
                      defaults: new { controller = "Movie", action = "Index" },
                      constraints : new {id = new IntRouteConstraint()}
                      );
                //  template+defaults+constraintscan be conbimed to : 
                //     template: "api/{controller=Products}/{action=Index}/{id:int?}",

                //  eg -> https://localhost:7266/api/Products/GetProducts
            });

           
            // Enable middleware to serve generated Swagger as a JSON endpoint.
            app.UseSwagger();

            // Enable middleware to serve swagger-ui (HTML, JS, CSS, etc.), 
            // specifying the Swagger JSON endpoint.
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "MoviesDB.API");
            });
        }
    }
}
