'use-strict';

(function (window) {
})(window);