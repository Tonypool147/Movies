'use-strict';

(function(window) {
    function bootstrapApp() {
        
    }
    $(bootstrapApp);
})(window);