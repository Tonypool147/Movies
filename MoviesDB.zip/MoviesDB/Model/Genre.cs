namespace Movies.Model 
{
    public class Genre {

        public long GenreId { get; set; }

        public string Name { get; set; }


    }
}
