using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace Movies.Model {
    public class MovieDTO {

        
        public DateTime Release_Date { get; set; }
     
        public string? Title { get; set; }
    
        public string? Overview { get; set; }

        // db holds genres as a csv string
        public string? Genres { get; set; }

        public string? Poster_Url { get; set; }

    }
}
