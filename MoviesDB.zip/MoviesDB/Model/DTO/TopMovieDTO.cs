using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace Movies.Model {
    public class TopMovieDTO
    {
        public string? Title { get; set; }

        public string Release_Date { get; set; }

        [Column(TypeName = "decimal(18, 1)")]
        public decimal Rating { get; set; }

    }
}
