using Microsoft.EntityFrameworkCore;

namespace Movies.Model {

    public class DataContext : DbContext {

        public DataContext(DbContextOptions<DataContext> opts) : base(opts) 
        { }

        public DbSet<Movie> Movies { get; set; }
        public DbSet<Genre> Genres { get; set; }

        public void SeedData(DataContext context)
        {

            context.Database.Migrate();

            if (context.Genres.Count() == 0)
            {

                context.Genres.AddRange(
                    new Genre { Name = "Action" },
                    new Genre { Name = "Adventure" },
                    new Genre { Name = "Science Fiction" },
                    new Genre { Name = "Crime" },
                    new Genre { Name = "Mystery" },
                    new Genre { Name = "Thriller" },
                    new Genre { Name = "Animation" },
                    new Genre { Name = "Comedy" },
                    new Genre { Name = "Fantasy" },
                    new Genre { Name = "War" },
                    new Genre { Name = "Horror" },
                    new Genre { Name = "Drama" },
                    new Genre { Name = "Romance" },
                    new Genre { Name = "Documentary" },
                    new Genre { Name = "History" }
                    );
                context.SaveChanges();
            }
        }
    }
}
