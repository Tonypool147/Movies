﻿using AutoMapper;
using log4net;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Movies.Model;
using MoviesDB.Model;
using System.Diagnostics;
using System.Linq;
using System.Net;
using MVC = Microsoft.AspNetCore.Mvc;
using System.Linq.Dynamic.Core;
using MoviesDB.Controllers;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;

namespace Movies.Controllers
{
    [MVC.Route("api/[controller]")]   
    [MVC.ApiController]
    public class MovieController : Controller
    {
        private static readonly ILog log = LogManager.GetLogger(typeof(MovieController));
        private DataContext context;
        private static readonly IMapper movieMapper;

        public MovieController(DataContext ctx)
        {
            context = ctx;
        }
        static MovieController()
        {
            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<Movie, MovieDTO>();

            });
            movieMapper = config.CreateMapper();

        }
        /// <summary>
        /// search by title
        /// search by detail as described in the Movie overview
        /// Restrict movies to 100 (user may enter text that potentailly could return a huge dataset)
        /// </summary>
        /// <param name="title"> URL movie/search?title=&sortBy=</param>
        /// <param name="details"> URL movie/search?details=&sortBy=param>
        /// <returns>list of movies [DTOs] for the title or details (not both) retricted to 100</returns>
        [MVC.HttpGet("Search")]
        public async Task<ActionResult<MovieDTO[]>> SearchMovies(string? title =null, string? details=null, string?      sortBy=null)
        {
            log.Debug("--- SearchMovies Method Start. ");

            var movies = new List<Movie>();
            try
            {
                if (title != null)
                {
                    movies = await context.Movies
                        .Where(p => p.Title!.Contains(title))
                        .OrderBy((sortBy != null && sortBy.ToLower().Trim() == "title") ?
                           "Title" : "Release_Date")
                        .ToListAsync();
                }
                else if (details != null)
                {
                    movies = await context.Movies
                        .Where(p => p.Overview!.Contains(details))
                        .OrderBy((sortBy != null && sortBy.ToLower().Trim() == "title") ?
                           "Title" : "Release_Date")
                        .ToListAsync();
                }

                return movieMapper.Map<MovieDTO[]>(movies.Take(100));
            }
            catch (Exception e1)
            {
                log.Error($"Error occurred with api call to SearchMovies {e1.Message}");
                return Content(e1.Message);
            }
            finally
            {
                log.Debug("--- SearchMovies Method End. ");
            }
        }

        /// <summary>
        /// return the movie from the movie ID
        /// </summary>
        /// <param name="id"></param>
        /// <returns>a single movie DTO</returns>
        [HttpGet("{id}")]  
        public async Task<ActionResult<MovieDTO>> Movie(int id)
        {
            var movie = await context.Movies
                .SingleOrDefaultAsync(p => p.MovieId == id);
                
            if (movie == null)
            {
                return NotFound();
            }
            
            return movieMapper.Map<MovieDTO>(movie);
        }

        /// <summary>
        /// return a list of movies for the genre
        /// </summary>
        /// <param name="genre"></param>
        /// <param name="sortBy">optional</param>
        /// <param name="pageSize">optional</param>
        /// <param name="page">optional</param>
        /// <returns>return a list of movies [DTO] for the genre, sorted and paged if these params are entered</returns>
        [MVC.HttpGet("SearchByGenre/{genre}")]
        public ActionResult<MovieDTO[]> SearchMoviesByGenre(string genre, string? sortBy = null, int ? pageSize = null, int? page = null)
        {
            List<Movie> movies = new List<Movie>();

            try
            {
                if (Common.PagingApplied(ref pageSize, ref page))
                {
                    movies = context.Movies
                       .Skip(((int)page! - 1) * (int)pageSize!)
                       .Take((int)pageSize!)
                       .AsEnumerable()
                       .Where(g => g.Genres != null &&
                                  g.Genres.Split(",", StringSplitOptions.TrimEntries).Contains(genre))
                       .ToList();
                }
                else
                {
                    movies = context.Movies
                       .AsEnumerable()
                       .Where(g => g.Genres != null &&
                                   g.Genres.Split(",", StringSplitOptions.TrimEntries).Contains(genre))
                       .ToList();
                }

                // cannot use OrderBy with condition within main LINQ so need to add it after 
                if (sortBy != null) movies = Common.OrderMovies(movies, sortBy);
           
                return Ok(movieMapper.Map<MovieDTO[]>(movies)); 
            }
            catch (Exception e1)
            {
                log.Error($"Error occurred with api call to SearchMoviesByGenre {e1.Message}");
            }
            finally
            {
                log.Debug("--- SearchMoviesByGenre Method End. ");
            }

            return Ok("No Results returned.");
        }

        /// <summary>
        /// get a list of movies for that have the actor mentioned in the overview
        /// </summary>
        /// <param name="actor"></param>
        /// <param name="sortBy"></param>
        /// <param name="pageSize"></param>
        /// <param name="page"></param>
        /// <returns>return a list of movies [DTO] that have the actor, sorted and paged if these params were entered</returns>
        [MVC.HttpGet("SearchByActor/{actor}")]
        public ActionResult<MovieDTO[]> SearchMoviesByActor(string actor, string? sortBy = null, int? pageSize = null, int? page = null)
        {
            List<Movie> movies = new List<Movie>();

            try
            {
                if (MoviesDB.Controllers.Common.PagingApplied(ref pageSize, ref page))
                {
                    movies = context.Movies
                        .Skip(((int)page!- 1) * (int)pageSize!)
                        .Take((int)pageSize!)
                        .Where(g => g.Overview != null &&
                                  g.Overview.Contains(actor))
                         .OrderBy((sortBy != null && sortBy.ToLower().Trim() == "title") ?
                           "Title" : "Release_Date")
                        .ToList();
                }
                else
                {
                    movies = context.Movies
                        .Where(g => g.Overview != null &&
                                   g.Overview.Contains(actor))
                         .OrderBy((sortBy != null && sortBy.ToLower().Trim() == "title") ?
                           "Title" : "Release_Date")
                        .ToList();
                }
               
                return Ok(movieMapper.Map<MovieDTO[]>(movies));
            }
            catch (Exception e1)
            {
                log.Error($"Error occurred with api call to SearchMoviesByGenre {e1.Message}");
            }
            finally
            {
                log.Debug("--- SearchMoviesByGenre Method End. ");
            }

            return Ok("No Results returned.");
        }
        /// <summary>
        /// Get the top 100 films by average vote AND with at least a vote count more than 20
        /// </summary>
        /// <param name="genre">optional - will be long query as no paging</param>
        /// <returns>return a list of top 100 movie DTO objects</returns>
        [MVC.HttpGet("Top100ByVote")]
        public ActionResult<TopMovieDTO[]> Top100MoviesByVote(string? genre = null)
        {
            log.Debug("--- Top100MovieByVote Method Start. ");

            List<Movie> movies = new List<Movie>();
            try
            {
                var mov = context.Movies
                       .Where(p => p.Vote_Count >= 20)
                       .OrderByDescending(p => p.Vote_Average)
                       .ToList();

                if (genre != null)
                {
                     movies = (List<Movie>)mov.AsEnumerable().Where(g => 
                            g.Genres!.Split(",", StringSplitOptions.TrimEntries).Contains(genre)).ToList();
                }
                else
                {
                    movies = mov;
                }

                 var movDTO = movies
                   .Select(p =>
                           new TopMovieDTO
                           {
                               Title = p.Title,
                               Release_Date = string.Format("{0:dd/MM/yyyy}", p.Release_Date),
                               Rating = p.Vote_Average
                           }
                       )
                   .ToList();

                return Ok(movDTO.Take(100));
            }
            catch (Exception e1)
            {
                log.Error($"Error occurred with api call to Top100MovieByVote {e1.Message}");
                return Content(e1.Message);
            }
            finally
            {
                log.Debug("--- Top100MovieByVote Method End. ");
            }
        }

        /// <summary>
        /// Get the top 100 films by popularity
        /// </summary>
        /// <returns>return a list of top 100 movie DTO objects</returns>
        [MVC.HttpGet("Top100ByPopularity")]
        public async Task<ActionResult<Movie[]>> Top100MoviesByPopularity()
        {
            log.Debug("--- Top100MoviesByPopularity Method Start. ");

            try
            {
                var mov = await context.Movies
                       .OrderByDescending(p => p.Popularity)
                       .Select(p =>
                            new TopMovieDTO
                            {
                                Title = p.Title,
                                Release_Date = string.Format("{0:dd/MM/yyyy}", p.Release_Date),
                                Rating = System.Convert.ToDecimal(string.Format("{0:0.0}",                    p.Popularity))
                            }
                        )
                       .ToListAsync();

                return Ok(mov.Take(100));
            }
            catch (Exception e1)
            {
                log.Error($"Error occurred with api call to Top100MoviesByPopularity {e1.Message}");
                return Content(e1.Message);
            }
            finally
            {
                log.Debug("--- Top100MoviesByPopularity Method End. ");
            }
        }

      /*  public IActionResult Index()
        {
             return View(context.Movies.First());
        }
      */

      /*  [MVC.HttpGet("Error")]  
        [MVC.ResponseCache(Duration = 0, Location = ResponseCacheLocation.None,
            NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel
            {
                RequestId = Activity.Current?.Id
                ?? HttpContext.TraceIdentifier
            });
        }*/
    }
}
