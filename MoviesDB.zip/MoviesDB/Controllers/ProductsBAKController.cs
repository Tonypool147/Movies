﻿using Microsoft.AspNetCore.Mvc;

namespace GiveNTake.Controllers
{
    // explict or atribute -based routing i.e. within the controller
    [Route ("asp/Products")]   // OR [Route("asp/[controller]")]
    [ApiController]
    public class ProductsController : Controller
    {
        // (1) When using explict routing i.e. within the controller
        // you need to add the http[verbattribute] to each method
        // (2) The routing defined in startup or webConfig will NOT work anymore
        [HttpGet("")]   // -> https://localhost:7266/asp/Products/ Doesn't work!
        [HttpGet("GetAllProducts")] // -> https://localhost:7266/asp/Products/GetAllProducts
        public string[] GetmyProducts()
        {
            return new[]
            {
                "1- Microwave",
                "2 - Washine Machine",
                "3 - Mirror"
            };
        }

        [HttpGet("search/id?")] // -> https://localhost:7266/asp/Products/search/id=25
                                // -> param productId = 25
        public string[] SearchProducts(int productId)
        {
            return new[] { "1- Microwave" };
        }

        [HttpGet("search/{keyword}")] // -> https://localhost:7266/asp/Products/search/microwave
                                      // -> param keyword = microwave
        public string[] SearchProducts(string keyword)
        {
            return new[] {"1- Microwave" }; 
        }

        [HttpGet("MyIndex")]
        // -> https://localhost:7266/asp/Products/MyIndex
        public string[] MyIndex()
        {
            return new[]
            {
                "1- Microwave2",
                "2 - Washine Machine2",
                "3 - Mirror2"
            };
        }
    }
}
