﻿using Microsoft.EntityFrameworkCore.Query.Internal;
using Microsoft.Identity.Client;
using Movies.Model;
using System.Drawing.Printing;
using System.Globalization;
using System.Linq.Expressions;
using System.Reflection.Metadata.Ecma335;

namespace MoviesDB.Controllers
{
    public class Common
    {
        private static readonly int? PAGESIZE = 100;

       public static List<Movie> OrderMovies(List<Movie> mov , string sortBy)
        {
            if (sortBy.ToLower().Trim() == "title")
            {
                return mov.OrderBy(p => p.Title).ToList();
            }
            else if (sortBy.ToLower().Trim() == "release_date")
            {
                return mov.OrderBy(p => p.Release_Date).ToList();
            }

            return mov;
        }

        public static bool PagingApplied(ref int? pageSize, ref int? page)
        {
            bool pagingApplied = false;

            if (pageSize != null)
            {
                pagingApplied = true;
            }
            else
            {
                return false;
            }

            if (pageSize == 0) pageSize = PAGESIZE;
            if ((page == null) || page != null && page == 0) page = 1;

            return pagingApplied;
        }
    }
}
